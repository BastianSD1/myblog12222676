canvas = document.getElementById("myCanvas");
ctx = canvas.getContext("2d");

--- = 100;
--- = 90;

--- = 10;
--- = 10;

background_image = "---";
rover_image = "---";

function add() {
	background_imgTag = new Image(); //define una variable con una nueva imagen
	background_imgTag.onload = ---; // establece una función para cargar esta variable
	background_imgTag.src = ---;   // carga la imagen

	rover_imgTag = new Image(); //define una variable con una nueva imagen
	rover_imgTag.onload = ---; // establece una función para cargar esta variable
	rover_imgTag.src = ---;   // carga la imagen
}

function uploadBackground() {
	ctx.drawImage(background_imgTag, 0, 0, canvas.width, canvas.height);
}

function uploadrover() {
	ctx.drawImage(rover_imgTag, rover_x, rover_y, rover_width, rover_height);
}

---.addEventListener("keydown", my_keydown);

function my_keydown(e) {
	keyPressed = e.keyCode;
	console.log(keyPressed);
		if(--- == '38') {
			up();
			console.log("---");
		}
		if(--- == '40') {
			down();
			console.log("---");
		}

		//Actividad adicional
		if(--- == '37') {
			left();
			console.log("---");
		}
		if(--- == '39') {
			right();
			console.log("---");
		}
		//La actividad adicional termina aquí
}

//Cubierto en la clase 85. 
function up() {
	if(rover_y >=0) {
		rover_y = rover_y - 10;
		console.log("Cuando se presione la flecha arriba,  x = " + rover_x + " | y = " +rover_y);
		 uploadBackground();
		 uploadrover();
	}
}

function down() {
	if(rover_y <=500) {
		rover_y =rover_y+ 10;
		console.log("Cuando se presione la flecha abajo,  x = " + rover_x + " | y = " +rover_y);
		uploadBackground();
		 uploadrover();
	}
}

function left() {
	if(rover_x >= 0) {
		rover_x =rover_x - 10;
		console.log("Cuando se presione la flecha izquierda,  x = " + rover_x + " | y = " +rover_y);
		uploadBackground();
		 uploadrover();
	}
}

function right() {
	if(rover_x <= 700) {
		rover_x =rover_x + 10;
		console.log("Cuando se presione la flecha derecha,  x = " + rover_x + " | y = " +rover_y);
		uploadBackground();
		uploadrover();
   }
}
	